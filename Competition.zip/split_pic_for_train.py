# coding=utf-8
# 该脚本是提取正样本和负样本
# Author: Gaochen
# Date: 2017.10.05

import tifffile as tiff
import matplotlib.pyplot as plt
import numpy as np
import os
import shutil
import cv2

root_dir='../training_pic/'
FILE_2015 = './data/quickbird2015.tif'
FILE_2017 = './data/quickbird2017.tif'
FILE_tinysample = './data/tinysample.tif'



def __init__():
    """
    该函数为初始化操作，创建图像保存路径
    """
    if os.path.exists(root_dir):
        print (root_dir+' exits,remove all')
        shutil.rmtree(root_dir)
    print (root_dir+' not exits,will be create')
    os.mkdir(root_dir)



def scale_percentile(matrix):
    """
    该函数是对图像进行标准化处理
    这样可以进行可视化，否则图像显示出来是一片黑
    Parameters
    ----------
        matrix: 图像中一个区域的矩阵，通道为蓝，绿，红，近地
    Returns
    -------
        matrix: 经过标准化处理之后的图像数据
    """
    w, h, d = matrix.shape
    # 先将数据reshape成一行数据
    matrix = np.reshape(matrix, [w * h, d]).astype(np.float64)
    # 通过百分位数获取数据的最大值和最小值进行标准化处理
    mins = np.percentile(matrix, 1, axis = 0)
    maxs = np.percentile(matrix, 99, axis = 0) - mins
    matrix = (matrix - mins[None, :]) / maxs[None, :]
    # 再将数据reshape成图像的大小
    matrix = np.reshape(matrix, [w, h, d])
    # matrix = matrix.clip(0, 1)
    return matrix



def create_samples(each_weight = 24, each_width = 24, weight_step = 2, width_step = 2):
    """
    分别读取2015、2017以及标注图像，然后根据标注图像选取正样本和负样本
    Parameters
    ----------
        each_weight: 每个样本图像的高度
        each_width: 每个样本图像的宽度
        weight_step: 每次图像高度方向滑动的大小
        width_step: 每次图像宽度方向滑动的大小
    """
    __init__()
    # 这里使用transpose将通道从bgr翻转成rgb
    im_2015 = tiff.imread(FILE_2015).transpose([1, 2, 0])
    im_2017 = tiff.imread(FILE_2017).transpose([1, 2, 0])
    im_tiny = cv2.imread(FILE_tinysample, -1)
    a, b = im_tiny.shape[ : 2]
    print('each_pic_size :', each_weight * each_width, '=', each_weight, '*', each_width)
    num = 0
    for i in range(int(((a - each_weight) / weight_step))):
        for j in range(int((b - each_width) / width_step)):
            hs = i * weight_step
            he = hs + each_weight
            ws = j * width_step
            we = ws + each_width
            test_tiny = im_tiny[hs:he, ws:we, 0]
            sum_tiny = test_tiny.sum()
            if sum_tiny > 50:
                num += 1
                test_2015 = scale_percentile(im_2015[hs:he, ws:we, :])
                test_2017 = scale_percentile(im_2017[hs:he, ws:we, :])
                # 将2015和2017图片中对应位置的图像叠加在一起, 作为样本图片
                test_input = np.concatenate((test_2015, test_2017), axis = 2)
                # 将标注图像存为label矩阵
                test_output = np.reshape(test_tiny, [each_weight * each_width])
                base_path = root_dir+'%d-%d&%d-%d_' % (hs, he, ws, we)
                tiff.imsave(base_path + 'input.tif', test_input)
                tiff.imsave(base_path + 'output.tif', test_output)
    print ('Samples num =',num)



if __name__ == "__main__":
    create_samples(24, 24)
